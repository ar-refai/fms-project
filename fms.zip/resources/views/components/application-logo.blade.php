<img src="{{asset('images/logo.png')}}" alt="logo" class="h-6 ">
