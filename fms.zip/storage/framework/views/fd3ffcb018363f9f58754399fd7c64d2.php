<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
            <?php echo e(__('Expenses')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm dark:bg-gray-800 sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <div class="relative p-2 overflow-x-auto shadow-md sm:rounded-lg">

                        
                        <div class="flex mb-6 space-x-4">
                            <button class="px-4 py-2 text-white transition rounded-md bg-sky-500 hover:bg-sky-600"
                                onclick="openModal('addExpenseModal')">
                                Add New Expense
                            </button>
                        </div>

                        
                        <?php if($errors->any()): ?>
                            <div class="p-4 mb-4 text-red-700 bg-red-100 rounded-md">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        
                        <div id="recipients-expense" class="p-8 mt-6 rounded shadow lg:mt-0">
                            <table id="expensesTable"
                                class="w-full text-sm text-left text-gray-900 data-table display stripe rtl:text-right dark:text-gray-100">
                                <thead
                                    class="text-xs text-gray-900 uppercase bg-gray-200 dark:bg-gray-700 dark:text-gray-100">
                                    <tr>
                                        <th>Accounting ID</th>
                                        <th>Date</th>
                                        
                                        <th>Expense Type</th>
                                        <th>Designation</th>
                                        <th>Basis</th>
                                        <th>Description</th>
                                        <th>Unit</th>
                                        <th>Unit Rate</th>
                                        <th>Quantity</th>
                                        <th>Total Amount</th>
                                        <th>Recipient</th>
                                        <th>Actions</th>
                                    </tr>
                                    
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($expense->accounting_id); ?></td>
                                            <td><?php echo e($expense->date); ?></td>
                                            
                                            <td><?php echo e($expense->expense_type); ?></td>
                                            <td><?php echo e($expense->designation); ?></td>
                                            <td><?php echo e($expense->basis); ?></td>
                                            <td><?php echo e($expense->description ?? 'N/A'); ?></td>
                                            <td><?php echo e($expense->unit); ?></td>
                                            <td><?php echo e($expense->unit_rate); ?></td>
                                            <td><?php echo e($expense->quantity); ?></td>
                                            <td><?php echo e(number_format($expense->total_amount, 2)); ?></td>
                                            <td><?php echo e($expense->recipient); ?></td>
                                            <td class="flex-col justify-start space-y-2">
                                                
                                                <button
                                                    onclick="openModal('editExpenseModal', <?php echo e(json_encode($expense)); ?>)"
                                                    class="w-full px-2 py-1 text-sm text-white bg-blue-600 rounded-md hover:bg-blue-700">
                                                    Edit
                                                </button>

                                                
                                                <button
                                                    onclick="openModal('deleteExpenseModal', { id: <?php echo e($expense->id); ?> })"
                                                    class="w-full px-2 py-1 text-sm text-white bg-red-600 rounded-md hover:bg-red-700">
                                                    Delete
                                                </button>
                                            </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                  <!-- Add Expense Modal -->
<div id="addExpenseModal"
class="fixed inset-0 z-50 hidden w-full h-full px-4 overflow-y-auto bg-gray-900 bg-opacity-60">
<div class="relative max-w-md mx-auto text-gray-100 bg-gray-800 rounded-md shadow-xl top-40">
    <div class="flex justify-end p-2">
        <button onclick="closeModal('addExpenseModal')" type="button"
            class="text-gray-400 bg-transparent hover:bg-gray-700 hover:text-white rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                xmlns="http://www.w3.org/2000/svg">
                <path fill-rule="evenodd"
                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                    clip-rule="evenodd"></path>
            </svg>
        </button>
    </div>
    <div class="p-6">
        <h3 class="mb-4 text-xl font-bold">Add New Expense</h3>
        <form method="POST" action="<?php echo e(route('expenses.store')); ?>">
            <?php echo csrf_field(); ?>
            <div>
                <label for="accounting_id" class="block text-sm">Accounting ID</label>
                <input type="text" name="accounting_id" id="accounting_id" required
                    class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
            </div>
            <div>
                <label for="date" class="block text-sm">Date</label>
                <input type="date" name="date" id="date" required
                    class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
            </div>
            <!-- Basis Field (Project) -->
            <div>
                <label for="basis" class="block text-sm">Project (Basis)</label>
                <select name="basis" id="basis" required
                    class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md" onchange="setProjectId(this)">
                    <option value="" disabled selected>Select Project</option>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($project->project_name); ?>" data-project-id="<?php echo e($project->id); ?>">
                            <?php echo e($project->project_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="hidden" name="project_id" id="project_id">
            </div>

            <div>
                <label for="expense_type" class="block text-sm">Expense Type</label>
                <select name="expense_type" id="expense_type" required
                    class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                    <option value="Logistics">Logistics</option>
                    <option value="Material Purchases">Material Purchases</option>
                    <option value="Fabrication & Installation">Fabrication & Installation</option>
                    <option value="G&A">G&A</option>
                    <option value="Factory">Factory</option>
                    <option value="Other Expenses">Other Expenses</option>
                </select>
            </div>

            <!-- Designation Field (Client) -->
            <div>
                <label for="designation" class="block text-sm">Designation (Client)</label>
                <select name="designation" id="designation" required
                    class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md" onchange="setClientId(this)">
                    <option value="" disabled selected>Select Client</option>
                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($client->client_name); ?>" data-client-id="<?php echo e($client->id); ?>">
                            <?php echo e($client->client_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <input type="hidden" name="client_id" id="client_id">
            </div>

            <!-- Rest of the fields remain unchanged -->
            <div>
                <label for="description" class="block text-sm">Description</label>
                <textarea name="description" id="description" class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md"></textarea>
            </div>
            <div>
                <label for="unit" class="block text-sm">Unit</label>
                <select name="unit" id="unit" required
                    class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                    <option value="" disabled selected>Select Unit</option>
                    <option value="Set">Set</option>
                    <option value="No">No</option>
                    <option value="Sheet">Sheet</option>
                    <option value="SQM">SQM</option>
                    <option value="Roll">Roll</option>
                    <option value="Pack">Pack</option>
                    <option value="Ampula">Ampula</option>
                    <option value="L.S">L.S</option>
                    <option value="Strip">Strip</option>
                    <option value="Box">Box</option>
                    <option value="Cubic Meter">Cubic Meter</option>
                    <option value="K.G">K.G</option>
                </select>
            </div>
            <div>
                <label for="unit_rate" class="block text-sm">Unit Rate</label>
                <input type="number" step="0.01" name="unit_rate" id="unit_rate"
                    class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
            </div>
            <div>
                <label for="quantity" class="block text-sm">Quantity</label>
                <input type="number" step="0.01" name="quantity" id="quantity"
                    class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
            </div>
            <div>
                <label for="total_amount" class="block text-sm">Total Amount</label>
                <input type="number" step="0.01" name="total_amount"
                    id="total_amount" required
                    class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
            </div>
            <div>
                <label for="recipient" class="block text-sm">Recipient</label>
                <input type="text" name="recipient" id="recipient" required
                    class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
            </div>
            <div class="flex justify-end mt-4 space-x-4">
                <button type="button" onclick="closeModal('addExpenseModal')"
                    class="px-4 py-2 text-white bg-gray-500 rounded-md hover:bg-gray-700">
                    Close
                </button>
                <button type="submit"
                    class="px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-800">
                    Add Expense
                </button>
            </div>
        </form>
    </div>
</div>
</div>

<!-- Edit Expense Modal -->
<div id="editExpenseModal"
    class="fixed inset-0 z-50 hidden w-full h-full px-4 overflow-y-auto bg-gray-900 bg-opacity-60">
    <div
        class="relative max-w-md mx-auto text-gray-100 bg-gray-800 rounded-md shadow-xl top-40">
        <div class="flex justify-end p-2">
            <button onclick="closeModal('editExpenseModal')" type="button"
                class="text-gray-400 bg-transparent hover:bg-gray-700 hover:text-white rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd"
                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                        clip-rule="evenodd"></path>
                </svg>
            </button>
        </div>
        <div class="p-6">
            <h3 class="mb-4 text-xl font-bold">Edit Expense</h3>
            <form method="POST" id="editExpenseForm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div>
                    <label for="edit_accounting_id" class="block text-sm">Accounting ID</label>
                    <input type="text" name="accounting_id" id="edit_accounting_id"
                        required class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                </div>
                <div>
                    <label for="edit_date" class="block text-sm">Date</label>
                    <input type="date" name="date" id="edit_date" required
                        class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                </div>
                <!-- Basis Field (Project) -->
                <div>
                    <label for="edit_basis" class="block text-sm">Project (Basis)</label>
                    <select name="basis" id="edit_basis" required
                        class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md" onchange="setEditProjectId(this)">
                        <option value="" disabled selected>Select Project</option>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($project->project_name); ?>" data-project-id="<?php echo e($project->id); ?>">
                                <?php echo e($project->project_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="hidden" name="project_id" id="edit_project_id">
                </div>
                <div>
                    <label for="edit_expense_type" class="block text-sm">Expense Type</label>
                    <select name="expense_type" id="edit_expense_type" required
                        class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                        <option value="Logistics">Logistics</option>
                        <option value="Material Purchases">Material Purchases</option>
                        <option value="Fabrication & Installation">Fabrication & Installation</option>
                        <option value="G&A">G&A</option>
                        <option value="Factory">Factory</option>
                        <option value="Other Expenses">Other Expenses</option>
                    </select>
                </div>
                <!-- Designation Field (Client) -->
                <div>
                    <label for="edit_designation" class="block text-sm">Designation (Client)</label>
                    <select name="designation" id="edit_designation" required
                        class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md" onchange="setEditClientId(this)">
                        <option value="" disabled selected>Select Client</option>
                        <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($client->client_name); ?>" data-client-id="<?php echo e($client->id); ?>">
                                <?php echo e($client->client_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="hidden" name="client_id" id="edit_client_id">
                </div>
                <div>
                    <label for="edit_description" class="block text-sm">Description</label>
                    <textarea name="description" id="edit_description" class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md"></textarea>
                </div>
                <div>
                    <label for="edit_unit" class="block text-sm">Unit</label>
                    <select name="unit" id="edit_unit" required
                        class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                        <option value="" disabled selected>Select Unit</option>
                        <option value="Set">Set</option>
                        <option value="No">No</option>
                        <option value="Sheet">Sheet</option>
                        <option value="SQM">SQM</option>
                        <option value="Roll">Roll</option>
                        <option value="Pack">Pack</option>
                        <option value="Ampula">Ampula</option>
                        <option value="L.S">L.S</option>
                        <option value="Strip">Strip</option>
                        <option value="Box">Box</option>
                        <option value="Cubic Meter">Cubic Meter</option>
                        <option value="K.G">K.G</option>
                    </select>
                </div>
                <div>
                    <label for="edit_unit_rate" class="block text-sm">Unit Rate</label>
                    <input type="number" step="0.01" name="unit_rate" id="edit_unit_rate"
                        class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                </div>
                <div>
                    <label for="edit_quantity" class="block text-sm">Quantity</label>
                    <input type="number" step="0.01" name="quantity" id="edit_quantity"
                        class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                </div>
                <div>
                    <label for="edit_total_amount" class="block text-sm">Total Amount</label>
                    <input type="number" step="0.01" name="total_amount"
                        id="edit_total_amount" required
                        class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                </div>
                <div>
                    <label for="edit_recipient" class="block text-sm">Recipient</label>
                    <input type="text" name="recipient" id="edit_recipient" required
                        class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                </div>
                <div class="flex justify-end mt-4 space-x-4">
                    <button type="button" onclick="closeModal('editExpenseModal')"
                        class="px-4 py-2 text-white bg-gray-500 rounded-md hover:bg-gray-700">
                        Close
                    </button>
                    <button type="submit"
                        class="px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-800">
                        Update Expense
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>


                        
                        <div id="deleteExpenseModal"
                            class="fixed inset-0 z-50 hidden w-full h-full px-4 overflow-y-auto bg-gray-900 bg-opacity-60">
                            <div
                                class="relative max-w-md mx-auto text-gray-100 bg-gray-800 rounded-md shadow-xl top-40">
                                <div class="flex justify-end p-2">
                                    <button onclick="closeModal('deleteExpenseModal')" type="button"
                                        class="text-gray-400 bg-transparent hover:bg-gray-700 hover:text-white rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414 1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                                clip-rule="evenodd"></path>
                                        </svg>
                                    </button>
                                </div>
                                <div class="p-6">
                                    <h3 class="mb-4 text-xl font-bold">Confirm Delete</h3>
                                    <p>Are you sure you want to delete this expense?</p>
                                    <form method="POST" id="deleteExpenseForm">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <div class="flex justify-center mt-4 space-x-4">
                                            <button type="button" onclick="closeModal('deleteExpenseModal')"
                                                class="px-4 py-2 text-white bg-gray-500 rounded-md hover:bg-gray-700">
                                                Cancel
                                            </button>
                                            <button type="submit"
                                                class="px-4 py-2 text-white bg-red-600 rounded-md hover:bg-red-800">
                                                Delete
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>



                    </div>
                </div>
            </div>
        </div>
    </div>



<script type="text/javascript">
    function openModal(modalId, data = {}) {
        const modal = document.getElementById(modalId);
        modal.style.display = 'block';
        document.body.classList.add('overflow-y-hidden');

        if (modalId === 'editExpenseModal' && data) {
            document.getElementById('edit_accounting_id').value = data.accounting_id || '';
            document.getElementById('edit_date').value = data.date ? data.date.split(' ')[0] : '';
            document.getElementById('edit_expense_type').value = data.expense_type || '';
            document.getElementById('edit_designation').value = data.designation || '';
            document.getElementById('edit_basis').value = data.basis || '';
            document.getElementById('edit_description').value = data.description || '';
            document.getElementById('edit_unit').value = data.unit || '';
            document.getElementById('edit_unit_rate').value = data.unit_rate || '';
            document.getElementById('edit_quantity').value = data.quantity || '';
            document.getElementById('edit_total_amount').value = data.total_amount || '';
            document.getElementById('edit_recipient').value = data.recipient || '';

            // Set hidden project_id and client_id values
            const projectOption = Array.from(document.getElementById('edit_basis').options)
                .find(option => option.text === data.basis);
            if (projectOption) {
                document.getElementById('edit_project_id').value = projectOption.getAttribute('data-project-id');
            }

            const clientOption = Array.from(document.getElementById('edit_designation').options)
                .find(option => option.text === data.designation);
            if (clientOption) {
                document.getElementById('edit_client_id').value = clientOption.getAttribute('data-client-id');
            }

            const form = document.getElementById('editExpenseForm');
            form.action = `/expenses/${data.id}`;
        }

        if (modalId === 'deleteExpenseModal' && data.id) {
            const form = document.getElementById('deleteExpenseForm');
            form.action = `/expenses/${data.id}`;
        }
    }

    function closeModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.style.display = 'none';
        document.body.classList.remove('overflow-y-hidden');
    }

    function setProjectId(element) {
        const projectId = element.options[element.selectedIndex].getAttribute('data-project-id');
        document.getElementById('project_id').value = projectId;
    }

    function setClientId(element) {
        const clientId = element.options[element.selectedIndex].getAttribute('data-client-id');
        document.getElementById('client_id').value = clientId;
    }

    function setEditProjectId(element) {
        const projectId = element.options[element.selectedIndex].getAttribute('data-project-id');
        document.getElementById('edit_project_id').value = projectId;
    }

    function setEditClientId(element) {
        const clientId = element.options[element.selectedIndex].getAttribute('data-client-id');
        document.getElementById('edit_client_id').value = clientId;
    }
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Mohamed\Herd\cut-to-size-fms\resources\views/expenses.blade.php ENDPATH**/ ?>