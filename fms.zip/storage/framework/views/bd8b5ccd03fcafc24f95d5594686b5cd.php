<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
            <?php echo e(__('Clients and Projects')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow-sm dark:bg-gray-800 sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <div class="relative p-2 overflow-x-auto shadow-md sm:rounded-lg">

                        
                        <?php if(session('success')): ?>
                            <div class="p-4 mb-4 text-green-700 bg-green-100 rounded-md">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="p-4 mb-4 text-red-700 bg-red-100 rounded-md">
                                <?php echo e(session('error')); ?>

                            </div>
                        <?php endif; ?>

                        
                        <div class="flex mb-6 space-x-4">
                            <button class="px-4 py-2 text-white transition rounded-md bg-sky-500 hover:bg-sky-600"
                                onclick="openModal('addClientModal')">
                                Add New Client
                            </button>

                            <button class="px-4 py-2 text-white transition rounded-md bg-sky-500 hover:bg-sky-600"
                                onclick="openModal('addProjectModal')">
                                Add New Project
                            </button>

                            <button class="px-4 py-2 text-white transition bg-gray-500 rounded-md hover:bg-gray-600"
                                onclick="openModal('viewAllClientsModal')">
                                View All Clients
                            </button>

                            <button class="px-4 py-2 text-white transition bg-gray-500 rounded-md hover:bg-gray-600"
                                onclick="openModal('viewAllProjectsModal')">
                                View All Projects
                            </button>
                        </div>
                        <?php if($errors->any()): ?>
                            <div class="p-4 mb-4 text-red-700 bg-red-100 rounded-md">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <?php if($errors->hasBag('deleteProject')): ?>
                            <div class="mb-4 text-red-700 bg-red-100 rounded-md">
                                <ul>
                                    <?php $__currentLoopData = $errors->getBag('deleteProject')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <?php if($errors->hasBag('addClient')): ?>
                            <div class="mb-4 text-red-700 bg-red-100 rounded-md">
                                <ul>
                                    <?php $__currentLoopData = $errors->getBag('addClient')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <?php if($errors->hasBag('addProject')): ?>
                            <div class="mb-4 text-red-700 bg-red-100 rounded-md">
                                <ul>
                                    <?php $__currentLoopData = $errors->getBag('addProject')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if($errors->hasBag('editProject')): ?>
                            <div class="mb-4 text-red-700 bg-red-100 rounded-md">
                                <ul>
                                    <?php $__currentLoopData = $errors->getBag('editProject')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if($errors->hasBag('editClient')): ?>
                            <div class="mb-4 text-red-700 bg-red-100 rounded-md">
                                <ul>
                                    <?php $__currentLoopData = $errors->getBag('editClient')->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <div id="recipients" class="p-8 mt-6 rounded shadow lg:mt-0">
                            <table id="clientsTable"
                                class="w-full text-sm text-left text-gray-900 display stripe rtl:text-right dark:text-gray-100">
                                <thead
                                    class="text-xs text-gray-900 uppercase bg-gray-200 dark:bg-gray-700 dark:text-gray-100">
                                    <tr>
                                        <th>Client ID</th>
                                        <th>Project ID</th>
                                        <th>Validation Date</th>
                                        <th>Client</th>
                                        <th>Type</th>
                                        <th>Project</th>
                                        <th>Contracted Revenue</th>
                                        <th>Accounts Receivables</th>
                                        <th>Collection Rate (%)</th>
                                        <th>Supply Cost</th>
                                        <th>Apply Cost</th>
                                        <th>Logistics Cost</th>
                                        <th>Gross Profit</th>
                                        <th>GPM (%)</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $dashboardData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($row['client_id']); ?></td>
                                            <td><?php echo e($row['project_id']); ?></td>
                                            <td><?php echo e($row['validation_date']); ?></td>
                                            <td><?php echo e($row['client']); ?></td>
                                            <td><?php echo e($row['type']); ?></td>
                                            <td><?php echo e($row['project']); ?></td>
                                            <td><?php echo e($row['contracted_revenue']); ?></td>
                                            <td><?php echo e($row['accounts_receivables']); ?></td>
                                            <td><?php echo e(number_format($row['collection_rate'], 2)); ?></td>
                                            <td><?php echo e($row['supply_cost']); ?></td>
                                            <td><?php echo e($row['apply_cost']); ?></td>
                                            <td><?php echo e($row['logistics_cost']); ?></td>
                                            <td><?php echo e($row['gross_profit']); ?></td>
                                            <td><?php echo e(number_format($row['gpm'], 2)); ?></td>
                                            <td><?php echo e($row['status']); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        
                        <div id="addClientModal"
                            class="fixed inset-0 z-50 hidden w-full h-full px-4 overflow-y-auto bg-gray-900 bg-opacity-60">
                            <div
                                class="relative max-w-md mx-auto text-gray-100 bg-gray-800 rounded-md shadow-xl top-40">
                                <div class="flex justify-end p-2">
                                    <button onclick="closeModal('addClientModal')" type="button"
                                        class="text-gray-400 bg-transparent hover:bg-gray-700 hover:text-white rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                                clip-rule="evenodd"></path>
                                        </svg>
                                    </button>
                                </div>
                                <div class="p-6">
                                    <h3 class="mb-4 text-xl font-bold">Add New Client</h3>



                                    <form method="POST" action="<?php echo e(route('clients.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div>
                                            <label for="client_code" class="block text-sm">Client Code</label>
                                            <input type="text" name="client_code" id="client_code"
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md <?php $__errorArgs = ['client_code', 'addClient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        </div>
                                        <div>
                                            <label for="client_name" class="block text-sm">Client Name</label>
                                            <input type="text" name="client_name" id="client_name"
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md <?php $__errorArgs = ['client_name', 'addClient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        </div>
                                        <div>
                                            <label for="client_type" class="block text-sm">Client Type</label>
                                            <input type="text" name="client_type" id="client_type"
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md <?php $__errorArgs = ['client_type', 'addClient'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        </div>
                                        <div class="flex justify-end mt-4 space-x-4">
                                            <button type="button" onclick="closeModal('addClientModal')"
                                                class="px-4 py-2 text-white bg-gray-500 rounded-md hover:bg-gray-700">
                                                Close
                                            </button>
                                            <button type="submit"
                                                class="px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-800">
                                                Add Client
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>


                        
                        <div id="addProjectModal"
                            class="fixed inset-0 z-50 hidden w-full h-full px-4 overflow-y-auto bg-gray-900 bg-opacity-60">
                            <div
                                class="relative max-w-md mx-auto text-gray-100 bg-gray-800 rounded-md shadow-xl top-40">
                                <div class="flex justify-end p-2">
                                    <button onclick="closeModal('addProjectModal')" type="button"
                                        class="text-gray-400 bg-transparent hover:bg-gray-700 hover:text-white rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414 1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                                clip-rule="evenodd"></path>
                                        </svg>
                                    </button>
                                </div>
                                <div class="p-6">
                                    <h3 class="mb-4 text-xl font-bold">Add New Project</h3>

                                    <form method="POST" action="<?php echo e(route('projects.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div>
                                            <label for="project_id" class="block text-sm">Project ID</label>
                                            <input type="text" name="project_id" id="project_id" required
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                                        </div>
                                        <div>
                                            <label for="project_name" class="block text-sm">Project Name</label>
                                            <input type="text" name="project_name" id="project_name" required
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                                        </div>
                                        <div>
                                            <label for="client_id" class="block text-sm">Client</label>
                                            <select name="client_id" id="client_id"
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                                                <option value="" disabled selected>Select Client</option>
                                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($client->id); ?>"><?php echo e($client->client_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div>
                                            <label for="contracted_revenue" class="block text-sm">Contracted
                                                Revenue</label>
                                            <input type="number" step="0.01" name="contracted_revenue"
                                                id="contracted_revenue" required
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                                        </div>
                                        <div>
                                            <label for="status" class="block text-sm">Status</label>
                                            <select name="status" id="status"
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                                                <option value="Pending" selected>Pending</option>
                                                <option value="In Progress">In Progress</option>
                                                <option value="Completed">Completed</option>
                                            </select>
                                        </div>
                                        <div>
                                            
                                            <input type="date" name="validation_date" id="validation_date"
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md"
                                                value="<?php echo e(now()->toDateString()); ?>" readonly hidden>
                                        </div>
                                        <div class="flex justify-end mt-4 space-x-4">
                                            <button type="button" onclick="closeModal('addProjectModal')"
                                                class="px-4 py-2 text-white bg-gray-500 rounded-md hover:bg-gray-700">
                                                Close
                                            </button>
                                            <button type="submit"
                                                class="px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-800">
                                                Add Project
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>



                        
                        <div id="viewAllProjectsModal"
                            class="fixed inset-0 z-50 hidden w-full h-full px-4 overflow-y-auto bg-gray-900 bg-opacity-60">
                            <div
                                class="relative max-w-4xl mx-auto text-gray-100 bg-gray-800 rounded-md shadow-xl top-40">
                                <div class="flex justify-end p-2">
                                    <button onclick="closeModal('viewAllProjectsModal')" type="button"
                                        class="text-gray-400 bg-transparent hover:bg-gray-700 hover:text-white rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                                clip-rule="evenodd"></path>
                                        </svg>
                                    </button>
                                </div>
                                <div class="p-6">
                                    <h3 class="mb-4 text-xl font-bold">All Projects</h3>
                                    <table id="minProjectTable"
                                        class="w-full text-sm text-left text-gray-100 bg-gray-800 data-table">
                                        <thead class="text-xs text-gray-100 bg-gray-700">
                                            <tr>
                                                <th>Project ID</th>
                                                <th>Project Name</th>
                                                <th>Client Name</th>
                                                <th>Contracted Revenue</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($project->project_id); ?></td>
                                                    <td><?php echo e($project->project_name); ?></td>
                                                    <td><?php echo e($project->client->client_name ?? 'N/A'); ?></td>
                                                    <td><?php echo e($project->contracted_revenue); ?></td>
                                                    <td><?php echo e($project->status); ?></td>
                                                    <td class="flex-col justify-center space-y-2 align-items-center">
                                                        <button
                                                            class="w-full px-2 py-1 text-sm text-white bg-blue-600 rounded-md hover:bg-blue-700"
                                                            onclick="openModal('editProjectModal', <?php echo e(json_encode($project)); ?>)">
                                                            Edit
                                                        </button>
                                                        <button
                                                            class="w-full px-2 py-1 text-sm text-white bg-red-600 rounded-md hover:bg-red-700"
                                                            onclick="openModal('deleteProjectModal', { id: <?php echo e($project->id); ?> })">
                                                            Delete
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        
                        <div id="editProjectModal"
                            class="fixed inset-0 z-50 hidden w-full h-full px-4 overflow-y-auto bg-gray-900 bg-opacity-60">
                            <div
                                class="relative max-w-md mx-auto text-gray-100 bg-gray-800 rounded-md shadow-xl top-40">
                                <div class="flex justify-end p-2">
                                    <button onclick="closeModal('editProjectModal')" type="button"
                                        class="text-gray-400 bg-transparent hover:bg-gray-700 hover:text-white rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                                clip-rule="evenodd"></path>
                                        </svg>
                                    </button>
                                </div>
                                <div class="p-6">
                                    <h3 class="mb-4 text-xl font-bold">Edit Project</h3>
                                    

                                    <form method="POST" id="editProjectForm">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div>
                                            <label for="edit_project_id" class="block text-sm">Project ID</label>
                                            <input type="text" name="project_id" id="edit_project_id" required
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md" disabled>
                                        </div>
                                        <div>
                                            <label for="edit_project_name" class="block text-sm">Project Name</label>
                                            <input type="text" name="project_name" id="edit_project_name" required
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                                        </div>
                                        <div>
                                            <label for="edit_client_id" class="block text-sm">Client</label>
                                            <select name="client_id" id="edit_client_id" required
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($client->id); ?>"><?php echo e($client->client_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div>
                                            <label for="edit_contracted_revenue" class="block text-sm">Contracted
                                                Revenue</label>
                                            <input type="number" step="0.01" name="contracted_revenue"
                                                id="edit_contracted_revenue" required
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                                        </div>
                                        <div>
                                            <label for="edit_status" class="block text-sm">Status</label>
                                            <select name="status" id="edit_status" required
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                                                <option value="Pending">Pending</option>
                                                <option value="In Progress">In Progress</option>
                                                <option value="Completed">Completed</option>
                                            </select>
                                        </div>
                                        <div class="flex justify-end mt-4 space-x-4">
                                            <button type="button" onclick="closeModal('editProjectModal')"
                                                class="px-4 py-2 text-white bg-gray-500 rounded-md hover:bg-gray-700">
                                                Cancel
                                            </button>
                                            <button type="submit"
                                                class="px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-800">
                                                Save Changes
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        
                        <div id="deleteProjectModal"
                            class="fixed inset-0 z-50 hidden w-full h-full px-4 overflow-y-auto bg-gray-900 bg-opacity-60">
                            <div
                                class="relative max-w-md mx-auto text-gray-100 bg-gray-800 rounded-md shadow-xl top-40">
                                <div class="flex justify-end p-2">
                                    <button onclick="closeModal('deleteProjectModal')" type="button"
                                        class="text-gray-400 bg-transparent hover:bg-gray-700 hover:text-white rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                                clip-rule="evenodd"></path>
                                        </svg>
                                    </button>
                                </div>
                                <div class="p-6">

                                    <h3 class="mb-4 text-xl font-bold">Confirm Delete</h3>
                                    <p>Are you sure you want to delete this project?</p>
                                    <form method="POST" id="deleteProjectForm">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <div class="flex justify-center mt-4 space-x-4">
                                            <button type="button" onclick="closeModal('deleteProjectModal')"
                                                class="px-4 py-2 text-white bg-gray-500 rounded-md hover:bg-gray-700">
                                                Cancel
                                            </button>
                                            <button type="submit"
                                                class="px-4 py-2 text-white bg-red-600 rounded-md hover:bg-red-800">
                                                Delete
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        
                        <div id="viewAllClientsModal"
                            class="fixed inset-0 z-50 hidden w-full h-full px-4 overflow-y-auto bg-gray-900 bg-opacity-60">
                            <div
                                class="relative max-w-4xl mx-auto text-gray-100 bg-gray-800 rounded-md shadow-xl top-40">
                                <div class="flex justify-end p-2">
                                    <button onclick="closeModal('viewAllClientsModal')" type="button"
                                        class="text-gray-400 bg-transparent hover:bg-gray-700 hover:text-white rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                                clip-rule="evenodd"></path>
                                        </svg>
                                    </button>
                                </div>
                                <div class="p-6">
                                    <h3 class="mb-4 text-xl font-bold">All Clients</h3>
                                    <table id="minClientTable"
                                        class="w-full text-sm text-left text-gray-100 bg-gray-800 data-table display ">
                                        <thead class="text-xs text-gray-100 bg-gray-700">
                                            <tr>
                                                <th>Client Code</th>
                                                <th>Client Name</th>
                                                <th>Client Type</th>
                                                <th>Created At</th>
                                                <th>Actions</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($client->client_code); ?></td>
                                                    <td><?php echo e($client->client_name); ?></td>
                                                    <td><?php echo e($client->client_type); ?></td>
                                                    <td><?php echo e($client->created_at); ?></td>
                                                    <td class="flex-col space-y-2">
                                                        <button
                                                            class="w-full px-2 py-1 text-sm text-white bg-blue-600 rounded-md hover:bg-blue-700"
                                                            onclick="openModal('editClientModal', <?php echo e(json_encode($client)); ?>)">
                                                            Edit
                                                        </button>
                                                        <button
                                                            class="w-full px-2 py-1 text-sm text-white bg-red-600 rounded-md hover:bg-red-700"
                                                            onclick="openModal('deleteClientModal', { id: <?php echo e($client->id); ?> })">
                                                            Delete
                                                        </button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                </div>

                            </div>
                        </div>

                        
                        <div id="editClientModal"
                            class="fixed inset-0 z-50 hidden w-full h-full px-4 overflow-y-auto bg-gray-900 bg-opacity-60">
                            <div
                                class="relative max-w-md mx-auto text-gray-100 bg-gray-800 rounded-md shadow-xl top-40">
                                <div class="flex justify-end p-2">
                                    <button onclick="closeModal('editClientModal')" type="button"
                                        class="text-gray-400 bg-transparent hover:bg-gray-700 hover:text-white rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                                clip-rule="evenodd"></path>
                                        </svg>
                                    </button>
                                </div>
                                <div class="p-6">
                                    <h3 class="mb-4 text-xl font-bold">Edit Client</h3>
                                    

                                    <form method="POST" id="editClientForm">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <div>
                                            <label for="edit_client_code" class="block text-sm">Client Code</label>
                                            <input type="text" name="client_code" id="edit_client_code"
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                                        </div>
                                        <div>
                                            <label for="edit_client_name" class="block text-sm">Client Name</label>
                                            <input type="text" name="client_name" id="edit_client_name"
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                                        </div>
                                        <div>
                                            <label for="edit_client_type" class="block text-sm">Client Type</label>
                                            <input type="text" name="client_type" id="edit_client_type"
                                                class="w-full p-2 mt-2 text-gray-100 bg-gray-700 rounded-md">
                                        </div>
                                        <div class="flex justify-end mt-4 space-x-4">
                                            <button type="button" onclick="closeModal('editClientModal')"
                                                class="px-4 py-2 text-white bg-gray-500 rounded-md hover:bg-gray-700">
                                                Cancel
                                            </button>
                                            <button type="submit"
                                                class="px-4 py-2 text-white bg-blue-600 rounded-md hover:bg-blue-800">
                                                Save Changes
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        
                        <div id="deleteClientModal"
                            class="fixed inset-0 z-50 hidden w-full h-full px-4 overflow-y-auto bg-gray-900 bg-opacity-60">
                            <div
                                class="relative max-w-md mx-auto text-gray-100 bg-gray-800 rounded-md shadow-xl top-40">
                                <div class="flex justify-end p-2">
                                    <button onclick="closeModal('deleteClientModal')" type="button"
                                        class="text-gray-400 bg-transparent hover:bg-gray-700 hover:text-white rounded-lg text-sm p-1.5 ml-auto inline-flex items-center">
                                        <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                                clip-rule="evenodd"></path>
                                        </svg>
                                    </button>
                                </div>
                                <div class="p-6">
                                    <h3 class="mb-4 text-xl font-bold">Confirm Delete</h3>
                                    <p>Are you sure you want to delete this client?</p>
                                    <form method="POST" id="deleteClientForm" action="">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <div class="flex justify-center mt-4 space-x-4">
                                            <button type="button" onclick="closeModal('deleteClientModal')"
                                                class="px-4 py-2 text-white bg-gray-500 rounded-md hover:bg-gray-700">
                                                Cancel
                                            </button>
                                            <button type="submit"
                                                class="px-4 py-2 text-white bg-red-600 rounded-md hover:bg-red-800">
                                                Delete
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <script type="text/javascript">
        function openModal(modalId, data = {}) {
            const modal = document.getElementById(modalId);
            modal.style.display = 'block';
            document.body.classList.add('overflow-y-hidden');
            if (modalId === 'editClientModal' && data) {
                    document.getElementById('edit_client_code').value = data.client_code || '';
                    document.getElementById('edit_client_name').value = data.client_name || '';
                    document.getElementById('edit_client_type').value = data.client_type || '';

                    const form = document.getElementById('editClientForm');
                    form.action = `/clients/${data.id}`;
                }

            if (modalId === 'editProjectModal' && data) {
                document.getElementById('edit_project_id').value = data.project_id || '';
                document.getElementById('edit_project_name').value = data.project_name || '';
                document.getElementById('edit_client_id').value = data.client_id || '';
                document.getElementById('edit_contracted_revenue').value = data.contracted_revenue || '';
                document.getElementById('edit_status').value = data.status || '';

                const form = document.getElementById('editProjectForm');
                form.action = `/projects/${data.id}`;
            }
            if (modalId === 'deleteClientModal' && data.id) {
                const form = document.getElementById('deleteClientForm');
                form.action = `/clients/${data.id}`;
            }
            if (modalId === 'deleteProjectModal' && data.id) {
                const form = document.getElementById('deleteProjectForm');
                form.action = `/projects/${data.id}`;
            }
        }


        function closeModal(modalId) {
            const modal = document.getElementById(modalId);
            modal.style.display = 'none';
            document.body.classList.remove('overflow-y-hidden');
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Mohamed\Herd\cut-to-size-fms\resources\views/clients.blade.php ENDPATH**/ ?>