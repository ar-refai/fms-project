<img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo" class="h-6 ">
<?php /**PATH C:\Users\Mohamed\Herd\cut-to-size-fms\resources\views/components/application-logo.blade.php ENDPATH**/ ?>