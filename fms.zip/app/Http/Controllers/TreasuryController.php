<?php

namespace App\Http\Controllers;

use App\Models\Treasury;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class TreasuryController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        try {
            $treasuries = Treasury::all();
            return view('treasury', compact('treasuries'));
        } catch (\Exception $e) {
            Log::error('Error fetching treasuries: ' . $e->getMessage());
            return redirect()->route('treasury.index')->with('error', 'Failed to load treasury records. Please try again later.');
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        try {
            return view('treasury.create');
        } catch (\Exception $e) {
            Log::error('Error loading treasury creation form: ' . $e->getMessage());
            return redirect()->route('treasury.index')->with('error', 'Failed to load the treasury creation form.');
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $validatedData = $request->validate([
                'treasury_id' => 'required|unique:treasuries',
                'date' => 'required|date',
                'starting_balance' => 'required|numeric',
                'type' => 'required|string',
                'amount' => 'required|numeric',
                'description' => 'nullable|string',
                'ending_balance' => 'required|numeric',
            ]);

            Treasury::create($validatedData);

            return redirect()->route('treasury.index')->with('success', 'Treasury record added successfully.');
        } catch (\Illuminate\Validation\ValidationException $e) {
            return redirect()->back()->withErrors($e->errors())->withInput();
        } catch (\Exception $e) {
            Log::error('Error creating treasury record: ' . $e->getMessage());
            return redirect()->route('treasury.index')->with('error', 'Failed to create treasury record. Please try again later.');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(Treasury $treasury)
    {
        try {
            return view('treasury.show', compact('treasury'));
        } catch (\Exception $e) {
            Log::error('Error displaying treasury record: ' . $e->getMessage());
            return redirect()->route('treasury.index')->with('error', 'Failed to load treasury record details.');
        }
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Treasury $treasury)
    {
        try {
            return view('treasury.edit', compact('treasury'));
        } catch (\Exception $e) {
            Log::error('Error loading treasury edit form: ' . $e->getMessage());
            return redirect()->route('treasury.index')->with('error', 'Failed to load the treasury edit form.');
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        try {
            $treasury = Treasury::findOrFail($id);

            $validatedData = $request->validate([
                'treasury_id' => 'required|unique:treasuries,treasury_id,' . $treasury->id,
                'date' => 'required|date',
                'starting_balance' => 'required|numeric',
                'type' => 'required|string',
                'amount' => 'required|numeric',
                'description' => 'nullable|string',
                'ending_balance' => 'required|numeric',
            ]);

            $treasury->update($validatedData);

            return redirect()->route('treasury.index')->with('success', 'Treasury record updated successfully.');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            Log::error('Treasury record not found: ' . $e->getMessage());
            return redirect()->route('treasury.index')->with('error', 'Treasury record not found.');
        } catch (\Illuminate\Validation\ValidationException $e) {
            return redirect()->back()->withErrors($e->errors())->withInput();
        } catch (\Exception $e) {
            Log::error('Error updating treasury record: ' . $e->getMessage());
            return redirect()->route('treasury.index')->with('error', 'Failed to update treasury record. Please try again later.');
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        try {
            $treasury = Treasury::findOrFail($id);
            $treasury->delete();

            return redirect()->route('treasury.index')->with('success', 'Treasury record deleted successfully.');
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            Log::error('Treasury record not found: ' . $e->getMessage());
            return redirect()->route('treasury.index')->with('error', 'Treasury record not found.');
        } catch (\Exception $e) {
            Log::error('Error deleting treasury record: ' . $e->getMessage());
            return redirect()->route('treasury.index')->with('error', 'Failed to delete treasury record. Please try again later.');
        }
    }
}
